package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UsuarioDAO {
	
	private PreparedStatement objPreparacionComando;
	private ResultSet objColocarResultado;
	private Connection objConexionBD;
	
}
